package org.ioad.spring.security.postgresql.payload.request;

public class OrganizationDataRequest {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
