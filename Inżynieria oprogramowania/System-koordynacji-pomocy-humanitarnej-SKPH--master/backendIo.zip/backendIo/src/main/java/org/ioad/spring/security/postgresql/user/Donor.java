//package org.ioad.spring.security.postgresql.user;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.Table;
//
//@Entity
//@Table(name = "donor")
//public class Donor extends SingleUser {
//    // Konstruktor
//    public Donor() {}
//
//    public Donor(String name, String surname, String pesel) {
//        super(name, surname, pesel); // Wywołanie konstruktora klasy bazowej UserInfo
//    }
//}
